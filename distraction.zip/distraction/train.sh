#!/usr/bin/env sh

TOOLS=/data/DTAA/code/z228757/ssd-caffe/SSD/caffe-ssd/build/tools

$TOOLS/caffe train \
  -solver=/mnt/DTAA_data/DTAA/code/z638420/code/code/caffe-ssd/caffe-ssd/examples/distraction_32/solver.prototxt \
  #-snapshot=/mnt/DTAA_data/DTAA/code/z638420/code/code/caffe-ssd/caffe-ssd/examples/distraction_32/snapshot/_iter_198000.solverstate \
  #-weights=/mnt/DTAA_data/DTAA/code/z638420/code/code/caffe-ssd/caffe-ssd/models/VGGNet/VGG_ILSVRC_16_layers.caffemodel \
  -gpu=1 \
